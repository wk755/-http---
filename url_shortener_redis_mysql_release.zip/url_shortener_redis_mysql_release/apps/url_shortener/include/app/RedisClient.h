#pragma once
#ifdef WITH_REDIS
#include <hiredis/hiredis.h>
#include <string>
#include <stdexcept>
#include <cstdarg>
namespace app {
class RedisClient {
  redisContext* ctx_{nullptr};
public:
  ~RedisClient(){ close(); }
  void connect(const std::string& host="127.0.0.1", int port=6379, int timeout_ms=200){
    close();
    struct timeval tv; tv.tv_sec = timeout_ms/1000; tv.tv_usec = (timeout_ms%1000)*1000;
    ctx_ = redisConnectWithTimeout(host.c_str(), port, tv);
    if (!ctx_ || ctx_->err) {
      std::string msg = ctx_ ? ctx_->errstr : "cannot allocate redis context";
      throw std::runtime_error(std::string("redis connect failed: ")+msg);
    }
  }
  void close(){ if (ctx_) { redisFree(ctx_); ctx_=nullptr; } }
  bool ok() const { return ctx_!=nullptr; }
  redisReply* cmd(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt);
    void* r = redisvCommand(ctx_, fmt, ap);
    va_end(ap);
    return (redisReply*)r;
  }
  static void free(redisReply* r){ if (r) freeReplyObject(r); }
}; } // namespace app
#endif
